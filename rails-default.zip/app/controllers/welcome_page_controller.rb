class WelcomePageController < ApplicationController
  def welcome
  end
end
